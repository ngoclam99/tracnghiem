<?php
//by honest
//2/3/2012
defined('DSVH') or die('Restricted access');
define('home','Đồ Họa Online | Trang chủ');
define('title','Danh sách thông báo');

?>