<?php
//by honest
//2/3/2012
defined('DSVH') or die('Restricted access');
define('home','| Trang chủ');
define('title','Danh sách tạp chí suối reo');
define('xem_tiep',' Xem tiếp »')

?>