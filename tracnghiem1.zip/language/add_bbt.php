<?php
//creat by phanliem
//27/02/2013

//text
define('heading_title','Liên Hệ');
define('ma_lien_he','Mã liên hệ');
define('tieu_de','Tiêu đề');
define('ten','Họ và tên');
define('dia_chi','Địa chỉ');
define('email','Địa chỉ Email');
define('dien_thoai','Số điện thoại');
define('noi_dung','Nội dung yêu cầu');
define('edit_success','Thêm cán bộ thành công');
define('ma_bao_mat','Mã bảo mật');
define('title','Ban Biên Tập');
define('ma_bao_ve','Mã bảo vệ');

?>