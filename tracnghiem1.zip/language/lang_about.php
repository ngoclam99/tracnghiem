<?php
//by honest
//2/3/2012
defined('DSVH') or die('Restricted access');
define('home','Giới thiệu shop đồ họa Online');
?>