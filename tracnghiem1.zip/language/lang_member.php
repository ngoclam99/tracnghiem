<?php
define('social_login','Đăng nhập bằng tài khoản mạng xã hội');
define('site_login','Đăng nhập bằng tài khoản đăng kí trên Danh Bạ Sơn La ');
define('g_login','Google');
define('fb_login','Facebook');
define('tg_login','Đăng nhập với Google');
define('tfb_login','Đăng nhập với Facebook');
define('login','Đăng nhập tài khoản');
define('reset_pwd','Lấy mật khẩu mới');
define('note_login','Nếu bạn chưa là thành viên vui lòng đăng kí tại <a href="./?m=member&act=register">đây</a> ');
define('agree','Đồng ý');
define('reg_mem','Đăng kí thành viên');
define('email','Thư điện tử');
define('user_name','Tên đăng nhập');
define('account_info','Thông tin tài khoản');
define('btn_reg','Đăng kí');
define('btn_cancel','Thôi');
define('entry_password','Mật khẩu');
define('entry_re_password','Xác nhận mật khẩu'); 
define('entry_name','Vui lòng nhập tên');
define('entry_profile','Hồ sơ'); 
define('entry_fullname','Tên đầy đủ'); 
define('entry_address','Địa chỉ'); 
define('entry_birthday','Ngày sinh'); 
define('entry_gender','Giới tính'); 
define('male','Nam');
define('female','Nữ');  
define('entry_homephone','Máy bàn'); 
define('entry_mobilephone','Di động'); 
define('entry_captcha','Mã xác nhận'); 
define('mat_khau','Vui lòng nhập mật khẩu'); 

define('er_leng_username','Độ dài mật khẩu phải lớn hơn hoặc bằng '); 
define('er_email','Email không hợp lệ'); 
define('er_leng_pwd','Độ dài mật khẩu lớn hơn hoặc bằng'); 
define('er_empty','Không được để trống');
define('er_captcha','Yêu cầu nhập mã bảo vệ');  
define('er_email_exist','Email đã sử dụng rồi'); 
define('er_email_emplty','Email bắt buộc phải có'); 
define('er_email','Email không hợp lệ'); 
define('er_match','Mã xác nhận không đúng'); 
define('er_repwd','Mật khẩu xác nhận không đúng'); 
define('er_name_exist','Tên đã tồn tại'); 
define('nhap_ten','Xin vui lòng nhập tên'); 

define('account','Tài khoản'); 
define('note','Thông báo'); 
define('reg_success_read_mail','Đăng kí thành công vui lòng kích hoạt mail để đăng nhập');

define('update','Cập nhật'); 
define('agree','Đồng ý'); 
define('edit_profile','Sửa thông tin cá nhân'); 
define('er_old_pwd','Mật khẩu cũ không đúng'); 
define('update_success','Cập nhật thành công'); 
define('text_nap_the','Nạp thẻ cho tài khoản'); 
define('nap_tien_vao_tai_khoan','Nạp tiền vào tài khoản');
define('sai_dinh_dang_the','Sai định dạng thẻ');
define('the_khong_dung','');   
define('nhap_sai','Nhập sai');
define('loi_he_thong','Lỗi hệ thống');
define('ip_cam','Bạn có hành vi gian lận khi nạp thẻ');
define('ten_dang_nhap_khong_dung','Kết nối ngân hàng bị gián đoạn');
define('loai_the_khong_dung','Loại thẻ không đúng');
define('he_thong_dang_bao_tri','Hệ thống đang bảo trì');
define('','');


?>