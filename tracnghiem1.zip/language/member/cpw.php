<?php
//creat by phanliem
//27/02/2013

//text
define('mat_khau_cu','Mật khẩu cũ');
define('mat_khau_moi','Mật khẩu mới');
define('xac_nhan_mat_khau','Xác nhận mật khẩu');
define('edit_success','Cập nhật thành công');


?>