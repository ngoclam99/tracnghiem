<?php
//creat by phanliem
//27/02/2013

//text
define('heading_title','Liên Hệ');
define('ten_dang_nhap','Tên đăng nhập');
define('mat_khau','Mật khẩu');
define('dang_nhap','Đăng nhập');
define('login','Đăng nhập');
define('email','Địa chỉ Email');
define('dien_thoai','Số điện thoại');
define('noi_dung','Nội dung yêu cầu');
define('edit_success','Thêm cán bộ thành công');
define('ma_bao_mat','Mã bảo mật');
define('reset_fpw','Lấy lại mật khẩu');
define('note','Nếu bạn chưa có tài khoản thì đăng ký tại');
define('day','Đây');

?>