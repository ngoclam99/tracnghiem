<?php
//creat by phanliem
//27/02/2013

//text
define('heading_title','Đặt phòng Online');
define('ma_lien_he','Mã liên hệ');
define('tieu_de','Tên khách sạn');
define('so_phong','Số phòng');
define('so_nguoi','Số người');
define('ngay_den','Ngày nhận phòng');
define('ngay_di','Ngày chả phong');
define('thanh_toan','Hình thức thanh toán');
define('ten','Họ tên');
define('email','Email');
define('dia_chi','Địa chỉ');
define('dien_thoai','Số điện thoại');
define('edit_success','Thêm cán bộ thành công');
define('ma_bao_mat','Mã bảo mật');
define('yeu_cau','Yêu cầu thêm');
define('title','Danh sách member');

?>