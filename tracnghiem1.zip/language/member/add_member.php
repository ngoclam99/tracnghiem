<?php
//creat by phanliem
//27/02/2013

//text
define('heading_title','Đăng ký tài khoản');
define('ma_lien_he','Mã liên hệ');
define('tieu_de','Tiêu đề');
define('ten','Họ và tên');
define('dia_chi','Địa chỉ');
define('email','Email');
define('avatar','Ảnh đại diện');
define('dien_thoai','Số điện thoại');
define('noi_dung','Nội dung yêu cầu');
define('edit_success','Cập nhật thành công');
define('ma_bao_mat','Mã bảo mật');
define('username','Tên tài khoản');
define('account_info','Thông tin cá nhân');
define('ho_so','Hồ sơ');
define('entry_password','Nhập mật khẩu');
define('ngay_sinh','Ngày sinh');
define('may_ban','Điện thoại');
define('dia_chi','Địa chỉ');
define('ho_ten','Họ và tên');
define('sai_ma','Mã xác nhận không đúng');
define('entry_captcha','Mã xác nhận');
define('edit_success1','Cập nhật thành công');
define('edit_success','Cập nhật thành công');
define('tai_khoan','Tài khoản');
define('lon_hon_3','Nhập từ 3 ký tự trở lên');
define('nhap_ma_captra','Yêu cầu nhập mã bảo vệ vào ô trống ');
define('sai_ma_bao_ve','Sai mã bảo vệ');
?>