<?php
//by honest
//2/3/2012
defined('DSVH') or die('Restricted access');
define('home','Văn bản - tài liệu');
define('tim_kiem','Tìm kiếm');
define('ten_van_ban','Tên văn bản');
define('so_hieu','Số hiệu');
define('noi_dung','Nội dung');
define('loai_tai_lieu','Loại tài liệu');
define('lua_chon','Lựa chọn');
define('tu_ngay','Từ ngày');
define('ngay_ban_hanh','Ngày ban hành');
define('noi_ban_hanh','Nơi ban hành');
?>