<?php
//by honest
//2/3/2012
defined('DSVH') or die('Restricted access');
define('home','| Trang chủ');
define('title','Trao đổi kiến thức học tập!');
define('xem_tiep',' Xem tiếp »')

?>