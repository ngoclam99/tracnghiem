<?php
//by honest
//2/3/2012
defined('DSVH') or die('Restricted access');
define('home','Cty Máy Tính Tân Cường | Trang chủ');
define('title','Danh sách album ảnh');

?>