<?php
    require('view/theme/default/template/home/test.html');
?>