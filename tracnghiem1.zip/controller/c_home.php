<?php

/**
 * @author ReDo
 * @copyright 2023
 */
    require('view/home/index.tpl');
?>
