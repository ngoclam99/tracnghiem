<?php
class Message
{
    public $statusCode;
    public $title;
    public $icon;
    public $content;
    public $pages = 1;
}
