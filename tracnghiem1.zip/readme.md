-- trắc nghiệm theo yêu cầu của bạn Bình IT Sơn La
-- mô tả yêu cầu: file word đính kèm
-- tài khoản admin: admin/sonla@123

Một câu hỏi phải có tối thiểu 2 đáp án, tối đa 6 đáp án
Module quản lý câu hỏi: thêm/sửa/xóa, import danh sách câu hỏi từ file excel.
Câu hỏi theo chủ đề với quan hệ 1-n.

Module Cuộc thi: thêm/sửa/xóa.
Cấu hình bài thi: đảo câu hỏi theo tỉ lệ % theo chủ đề.
Cùng 1 cuộc thi nhưng mỗi người sẽ có 1 đề thi khác nhau theo cấu hình đã lưu
