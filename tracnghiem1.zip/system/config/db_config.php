<?php
	$host='localhost';
	$user='root';
	$pass='huongliem';
	$db='DATN';
	$prefix='';
?>