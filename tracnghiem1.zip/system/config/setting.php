<?php
/**
 * @author honestphan
 * @copyright 2011
 *
 * This config file was genarated by honest
 * don't change any text
**/
//defined('SLA') or die('Restricted access');
//define('DIRECTORY_SEPARATOR','/');
//define('DIR_CACHE', 'E:\F\AppServ\www\da/caching/');
//system config
//define('CHAR_SET', config('char_set'));
define('cho_phep_them_di_san_dac_sac_tu_ngoai','0');
define('by_login','0');

?>